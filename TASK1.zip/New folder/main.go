// main.go
package main

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/jrallison/go-workers"
)

func main() {
	r := gin.Default()

	// Route to initiate background job
	r.POST("/process-data", ProcessData)

	// Start the Gin server
	go r.Run(":8080")

	// Start the worker to process background jobs
	workers.Configure(map[string]string{
		"server":   "127.0.0.1:6379", // Use IPv4 address
		"database": "0",
		"process":  "1",
	})

	// Register the background job
	workers.Process("email", SendEmail, 10)

	// Wait for the worker to finish
	workers.Run()
}

// Handler function for initiating background job
func ProcessData(c *gin.Context) {
	// Enqueue the job
	workers.Enqueue("email", "", nil) // The second argument is the name of the function to execute, but we don't need it here
	c.JSON(http.StatusOK, gin.H{"message": "Job enqueued successfully"})
}

// Worker function to send email (Example)
func SendEmail(msg *workers.Msg) {
	// Simulate email sending task
	fmt.Println("Sending email...")
}
