// main.go
package main

import (
	"encoding/json"
	"io/ioutil"
	"net/http"

	"github.com/gin-gonic/gin"
)

type AdviceResponse struct {
	Slip struct {
		ID     int    `json:"id"`
		Advice string `json:"advice"`
	} `json:"slip"`
}

func main() {
	r := gin.Default()

	r.GET("/advice", GetAdvice)

	r.Run(":8080")
}

func GetAdvice(c *gin.Context) {
	// (Advice Slip JSON API)
	resp, err := http.Get("https://api.adviceslip.com/advice")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch advice"})
		return
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read response body"})
		return
	}

	// Parse JSON response
	var adviceResp AdviceResponse
	if err := json.Unmarshal(body, &adviceResp); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to parse advice"})
		return
	}

	// Return advice
	c.JSON(http.StatusOK, gin.H{
		"advice": adviceResp.Slip.Advice,
	})
}
