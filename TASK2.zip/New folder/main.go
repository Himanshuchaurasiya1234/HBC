package main

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

type User struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
	Age  int    `json:"age"`
}

var users = []User{
	{ID: 1, Name: "Alice", Age: 30},
	{ID: 2, Name: "Bob", Age: 35},
	{ID: 3, Name: "Charlie", Age: 25},
	{ID: 4, Name: "David", Age: 40},
	{ID: 5, Name: "Eve", Age: 28},
	{ID: 6, Name: "Frank", Age: 32},
	{ID: 7, Name: "Grace", Age: 37},
	{ID: 8, Name: "Hannah", Age: 22},
	{ID: 9, Name: "Ivy", Age: 31},
	{ID: 10, Name: "Jack", Age: 29},
	{ID: 11, Name: "Kate", Age: 33},
	{ID: 12, Name: "Liam", Age: 27},
}

func main() {
	r := gin.Default()

	r.GET("/users", GetUsers)

	r.Run(":8080")
}

func GetUsers(c *gin.Context) {
	pageStr := c.DefaultQuery("page", "1")
	pageSizeStr := c.DefaultQuery("page_size", "10")
	search := c.Query("search")

	page, err := strconv.Atoi(pageStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid page number"})
		return
	}
	pageSize, err := strconv.Atoi(pageSizeStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid page size"})
		return
	}
	var result []User
	for _, user := range users {
		if search == "" || user.Name == search {
			result = append(result, user)
		}
	}

	startIndex := (page - 1) * pageSize
	endIndex := min(startIndex+pageSize, len(result))
	paginatedUsers := result[startIndex:endIndex]

	c.JSON(http.StatusOK, paginatedUsers)
}

// run on http://localhost:8080/users
